// CodexZhLocal.js - 免梯子中文界面注入器 (OpenAI Codex / ChatGPT MSIX) v6
//
// 适配版本: OpenAI.Codex 26.1021.x (MSIX OpenAI.Codex_26.1021.3705.0), 桌面版 26.1021.31345
//
// v5 → v6 逆向变更说明 (基于 CDP 运行时实测 + REA/Ghidra 对 app.asar 的分析):
//
//   1. 语言门控层 ID 不变: Statsig layer `72216192`, 键 `enable_i18n` / `locale_source`。
//
//   2. locale_source="SYSTEM" 在新版里是离线最优解:
//      - getLocaleInfo() 走本地 IPC (main 进程 app.getSystemLocale()), 不走远端。
//      - 系统语言为 zh-CN 时, resolvedLocale = zh-CN → 加载 asar 内打包的
//        zh-CN-bd2cd8444335.js (2.9MB), 无需网络。
//      - 若系统语言是英文, 则 UI 也会是英文, 这是预期行为。
//
//   3. ★ 最大坑 (v5→v6 核心修复): Statsig localStorage 缓存键 (storageKey) 是
//        djb2("uid:<userID>|cids:<customIDs>|k:<sdkKey>") 的后 8 位 hex。
//        登录态 userID 变化 → 键变化 → 旧键 (匿名/旧账号) 的缓存不被读取。
//      旧脚本写死旧键, 登录态下 SDK 读不到 → 冷启动恢复失败 → UI 回退英文。
//      修复: 注入时调用 c.dataAdapter._getCacheKey(c._user) 动态取当前键,
//      并补齐同前缀 (statsig.cached.<suffix>.) 的匿名/登录两个键 (只写不删,
//      因为登录态切换后 SDK 会改读另一个键, 删掉对方的键会导致恢复失败)。
//
//   4. SDK 内部结构不变, 可继续直接写:
//        __STATSIG__.{instances, firstInstance}
//        client._store.setValues({source,data,receivedAt,...}, user[, receivedAt])
//        data 为 JSON 字符串, V1 wire format:
//          layer_configs[ID] = { value:{...}, group_name, rule_id }
//
//   5. $emt 在 v5+ 接受 {name} 对象参数, 不再是裸字符串。已适配。
//
//   6. 本地兜底: 若 Statsig 注入后 UI 仍是英文, 把 localeOverride 写进
//        ~/.codex/config.toml (settingsStore 底层 TOML), 主进程 onDidChange
//        监听该键, 写文件后需重启应用才生效。
//
// 用法: node CodexZhLocal.js [cdp-port=9222]
//       (若端口未监听, 自动以 --remote-debugging-port=<port> 启动 MSIX)

const http = require("http");
const { spawn, execSync } = require("child_process");

const CDP_PORT = parseInt(process.env.CDP_PORT || process.argv[2] || "9222", 10);
const LAYER_ID = "72216192";
const TARGET_LOCALE = "zh-CN";
const LOG = (m) => console.log(new Date().toISOString().slice(11, 19), m);

// 自动探测已安装的 Codex/ChatGPT MSIX 安装路径
function detectMsixRoot() {
  if (process.env.CODEX_MSIX_ROOT) return process.env.CODEX_MSIX_ROOT;
  try {
    const out = execSync(
      'powershell -NoProfile -Command "Get-AppxPackage OpenAI.Codex | Select-Object -ExpandProperty InstallLocation"',
      { encoding: "utf8", windowsHide: true }
    ).trim();
    if (out) return out;
  } catch (e) { /* fall through */ }
  throw new Error("未找到 OpenAI.Codex 安装路径。请先安装 Codex 桌面版, 或设置环境变量 CODEX_MSIX_ROOT。");
}
const MSIX_ROOT = detectMsixRoot();

function cdpFetch(port, path) {
  return new Promise((resolve, reject) => {
    const req = http.get(`http://127.0.0.1:${port}${path}`, (res) => {
      let d = "";
      res.on("data", (c) => (d += c));
      res.on("end", () => resolve(d));
      res.on("error", reject);
    });
    req.on("error", reject);
  });
}
async function cdpAlive(port) {
  try { await cdpFetch(port, "/json/version"); return true; } catch { return false; }
}
async function waitForCdp(port, ms = 90000) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) {
    try {
      const list = JSON.parse(await cdpFetch(port, "/json/list"));
      if (Array.isArray(list) && list.length) return list;
    } catch {}
    await new Promise((r) => setTimeout(r, 1500));
  }
  throw new Error(`CDP 端口 ${port} 无可用目标`);
}

class Cdp {
  constructor(url){ this.url=url; this.id=0; this.waiters=new Map(); this.handlers=new Map(); }
  connect(){
    return new Promise((ok,fail)=>{
      const ws=new WebSocket(this.url); this.ws=ws;
      ws.onopen=()=>ok(this);
      ws.onerror=()=>fail(new Error("CDP websocket 连接失败"));
      ws.onmessage=(m)=>{
        const msg=JSON.parse(typeof m.data==="string"?m.data:Buffer.from(m.data).toString());
        if(msg.id!=null&&this.waiters.has(msg.id)){const w=this.waiters.get(msg.id);this.waiters.delete(msg.id);
          msg.error?w.reject(new Error(JSON.stringify(msg.error))):w.resolve(msg.result);}
        else if(msg.method){const hs=this.handlers.get(msg.method);if(hs)hs.forEach((f)=>f(msg.params,msg));}
      };
    });
  }
  send(method,params={}){const id=++this.id;return new Promise((resolve,reject)=>{
    this.waiters.set(id,{resolve,reject});this.ws.send(JSON.stringify({id,method,params}));
    setTimeout(()=>{if(this.waiters.has(id)){this.waiters.delete(id);reject(new Error("CDP 超时: "+method));}},30000);
  });}
  on(method,fn){if(!this.handlers.has(method))this.handlers.set(method,[]);this.handlers.get(method).push(fn);}
  eval(expr,awaitPromise=false){return this.send("Runtime.evaluate",{expression:expr,returnByValue:true,awaitPromise});}
  close(){try{this.ws.close();}catch{}}
}

// 注入到页面里执行的核心逻辑 (在 renderer 上下文):
//   1. 取 __STATSIG__ 所有实例
//   2. V1 wire format JSON 字符串直接写 client._store.setValues:
//        layer_configs[72216192] = { value:{enable_i18n:true, locale_source:"SYSTEM"},
//                                    group_name, rule_id }
//   3. 清除 _memoCache 中该 layer 的 memo 键 ("l|72216192")
//   4. client.$emt({name:"values_updated"}) 触发 React 重渲染
//   5. 持久化到 localStorage:
//        ★ 键通过 c.dataAdapter._getCacheKey(c._user) 动态获取, 不写死
//        并清掉同前缀的其他过期缓存键
//   6. 报告 before/after layer 值 + UI 中文关键词命中情况
const injectExpr = `(function(){
  var L = ${JSON.stringify(LAYER_ID)};
  var out = { found: 0, patched: 0, persisted: false, before: {}, after: {}, ui: {}, cacheKey: null, errors: [] };
  function readLayer(c){
    var cur = c.getLayer ? c.getLayer(L) : null;
    if (!cur) return null;
    var o = {};
    try {
      o.enable_i18n = cur.get ? cur.get("enable_i18n", null) : (cur.value || {}).enable_i18n ?? null;
      o.locale_source = cur.get ? cur.get("locale_source", null) : (cur.value || {}).locale_source ?? null;
      o.reason = cur.details ? cur.details.reason : (cur.value && cur.value.reason) || null;
    } catch (e) { o.readErr = String(e); }
    return o;
  }
  function uiCheck(){
    var zhUi = ["设置","新对话","定时","插件","项目","最近","书签","模型","语音","文件","关闭","取消","搜索","帮助","语言"];
    var enUi = ["Settings","New chat","Scheduled","Plugins","Projects","Recents","Bookmarks","Model","Voice","Files","Cancel","Search","Help","Language"];
    var text = (document.body && document.body.innerText || "");
    return {
      zhUiHits: zhUi.filter(function(w){ return text.indexOf(w) >= 0; }),
      enUiHits: enUi.filter(function(w){ return text.indexOf(w) >= 0; }),
      docLang: document.documentElement.lang
    };
  }
  function emitValuesUpdated(c){
    try {
      if (typeof c.$emt === "function") { c.$emt({ name: "values_updated" }); return "$emt"; }
      if (typeof c.emit === "function") { c.emit("values_updated"); return "emit"; }
    } catch (e) {}
    return null;
  }

  try {
    var g = (typeof __STATSIG__ !== "undefined") ? __STATSIG__ : null;
    if (!g) { out.errors.push("no __STATSIG__ global"); }
    else {
      var insts = (g.instances && Object.keys(g.instances).length) ? g.instances
                 : (g.firstInstance ? { first: g.firstInstance } : null);
      if (!insts) { out.errors.push("no statsig instances"); }
      else {
        var list = [];
        Object.keys(insts).forEach(function(k){ list.push({ key: k, c: insts[k] }); });
        out.found = list.length;
        list.forEach(function(item){
          var c = item.c;
          try {
            out.before[item.key] = readLayer(c);

            var payloadObj = {
              has_updates: true,
              time: Date.now(),
              feature_gates: {},
              dynamic_configs: {},
              layer_configs: {
                [L]: {
                  value: { enable_i18n: true, locale_source: "SYSTEM" },
                  group_name: L,
                  rule_id: "l|" + L
                }
              },
              param_stores: {},
              exposures: []
            };
            var payloadStr = JSON.stringify(payloadObj);

            var storeOk = false;
            if (c._store && c._store.setValues) {
              var storeArg = {
                source: "Bootstrap",
                data: payloadStr,
                receivedAt: Date.now(),
                stableID: null,
                fullUserHash: null
              };
              storeOk = c._store.setValues(storeArg, c._user, Date.now());
              if (storeOk === false && c._store.setValues.length === 2) {
                storeOk = c._store.setValues(storeArg, c._user);
              }
            } else {
              out.errors.push("client " + item.key + " has no _store.setValues");
            }
            out[item.key + "_storeOk"] = storeOk;

            var mc = c._memoCache || {};
            var cleared = [];
            for (var k2 in mc) {
              if (k2.indexOf(L) >= 0) {
                delete mc[k2]; cleared.push(k2);
              }
            }
            out[item.key + "_memoCleared"] = cleared;
            if (storeOk !== false) out.patched++;

            out[item.key + "_emit"] = emitValuesUpdated(c);

            // ★ v6: 缓存键随登录状态变化 (匿名/登录 djb2 输入不同)。
            // 注入时客户端可能还是匿名用户, 登录后会切到登录用户键。
            // 所以: 写当前键 + 补齐所有已存在的同前缀键 (不删除任何键)。
            var cacheKey = null;
            try {
              if (c.dataAdapter && c.dataAdapter._getCacheKey) {
                cacheKey = c.dataAdapter._getCacheKey(c._user);
              }
            } catch (ee) { out.errors.push("_getCacheKey: " + ee.message); }
            var suffix = c.dataAdapter ? (c.dataAdapter._cacheSuffix || "evaluations") : "evaluations";
            var cacheValue = {
              source: "Bootstrap",
              data: payloadStr,
              receivedAt: Date.now(),
              stableID: null,
              fullUserHash: null
            };
            var writtenKeys = [];
            try {
              var lmtKey = "statsig.last_modified_time." + suffix;
              var lmtRaw = localStorage.getItem(lmtKey);
              var lmt = lmtRaw ? JSON.parse(lmtRaw) : {};
              var cachedPrefix = "statsig.cached." + suffix + ".";
              // 1) 先收集所有已存在的同前缀缓存键 (匿名/登录用户的键)
              var existingKeys = [];
              for (var li = 0; li < localStorage.length; li++) {
                var lk = localStorage.key(li);
                if (lk && lk.indexOf(cachedPrefix) === 0) existingKeys.push(lk);
              }
              // 2) 当前键必写; 已存在的其他键也补齐 (登录切换后任一状态都能恢复)
              var toWrite = existingKeys.slice();
              if (cacheKey && toWrite.indexOf(cacheKey) < 0) toWrite.push(cacheKey);
              toWrite.forEach(function(kk) {
                localStorage.setItem(kk, JSON.stringify(cacheValue));
                lmt[kk] = Date.now();
                writtenKeys.push(kk);
              });
              localStorage.setItem(lmtKey, JSON.stringify(lmt));
            } catch (ee2) { out.errors.push("cache write: " + ee2.message); }
            if (writtenKeys.length) {
              out.persisted = true;
              out.persistKey = cacheKey;
              out.persistKeys = writtenKeys;
              out.persistSuffix = suffix;
            }

            out.after[item.key] = readLayer(c);
          } catch (e) { out.errors.push(item.key + ": " + e.message); }
        });
      }
    }
  } catch (e) { out.errors.push(String(e)); }

  out.ui = uiCheck();
  return JSON.stringify(out);
})();`;

// 本地兜底: 把 localeOverride 写进 ~/.codex/config.toml
const fs = require("fs");
const os = require("os");
const path = require("path");
function patchLocalLocaleOverride() {
  const report = { tried: false, files: [], patched: [] };
  const home = process.env.USERPROFILE || os.homedir();
  const codexHome = process.env.CODEX_HOME ? path.resolve(process.env.CODEX_HOME) : path.join(home, ".codex");

  const tomlPath = path.join(codexHome, "config.toml");
  if (fs.existsSync(tomlPath)) {
    report.files.push(tomlPath);
    let raw = fs.readFileSync(tomlPath, "utf8");
    if (/"localeOverride"\s*=/.test(raw) || /^\s*localeOverride\s*=/m.test(raw)) {
      const next = raw.replace(/^([ \t]*)("?localeOverride"?[ \t]*=).*$/m, "$1localeOverride = \"" + TARGET_LOCALE + "\"");
      if (next !== raw) {
        fs.writeFileSync(tomlPath, next);
        report.patched.push(tomlPath + " -> localeOverride=" + TARGET_LOCALE + " (config.toml)");
      } else {
        report.patched.push(tomlPath + " (already " + TARGET_LOCALE + ")");
      }
    } else {
      fs.writeFileSync(tomlPath, raw + "\nlocaleOverride = \"" + TARGET_LOCALE + "\"\n");
      report.patched.push(tomlPath + " -> appended localeOverride=" + TARGET_LOCALE);
    }
  }

  const jsonRoots = [codexHome, path.join(home, "AppData", "Local", "OpenAI")];
  const seen = new Set();
  function walk(dir, depth) {
    if (depth > 6) return;
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const ent of entries) {
      if (ent.name.startsWith(".")) continue;
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) { walk(p, depth + 1); continue; }
      if (!/\.json$/i.test(ent.name)) continue;
      if (seen.has(p)) continue;
      seen.add(p);
      let raw;
      try { raw = fs.readFileSync(p, "utf8"); } catch { continue; }
      if (raw.indexOf("localeOverride") < 0) continue;
      report.files.push(p);
      try {
        const obj = JSON.parse(raw);
        if (obj && typeof obj === "object") {
          obj.localeOverride = TARGET_LOCALE;
          fs.writeFileSync(p, JSON.stringify(obj, null, 2));
          report.patched.push(p + " -> localeOverride=" + TARGET_LOCALE);
        }
      } catch {}
    }
  }
  for (const r of jsonRoots) if (fs.existsSync(r)) walk(r, 0);

  report.tried = true;
  return report;
}

async function main() {
  LOG(`CDP 端口: ${CDP_PORT}`);
  if (!(await cdpAlive(CDP_PORT))) {
    LOG(`端口未监听, 以 --remote-debugging-port=${CDP_PORT} 启动 MSIX ...`);
    const p = spawn(`${MSIX_ROOT}\\app\\ChatGPT.exe`, [`--remote-debugging-port=${CDP_PORT}`], { detached: true, stdio: "ignore", windowsHide: true });
    p.unref();
  }
  const list = await waitForCdp(CDP_PORT);
  LOG(`目标 ${list.length} 个:`);
  list.forEach((t) => LOG(`  [${t.type}] ${t.title}  ${t.url}`));

  // 主界面 target: Statsig client 只在 app://-/index.html 页面
  // 冷启动时主窗口可能晚于辅助窗口注册, 轮询等待最多 60s
  let mainTarget = null;
  {
    const t0 = Date.now();
    for (;;) {
      const cur = list;
      mainTarget =
        cur.find((t) => t.type === "page" && /index\.html/i.test(t.url)) ||
        cur.find((t) => t.type === "page" && /app:\/\//i.test(t.url) && !/detached|popup|iframe/i.test(t.url));
      if (mainTarget || Date.now() - t0 > 60000) break;
      await new Promise((r) => setTimeout(r, 2000));
      try {
        const fresh = JSON.parse(await cdpFetch(CDP_PORT, "/json/list"));
        if (Array.isArray(fresh) && fresh.length) { list.length = 0; fresh.forEach((x) => list.push(x)); }
      } catch {}
    }
  }
  if (!mainTarget) throw new Error("未找到 index.html 主页面目标 (可能需先登录/应用未就绪)");
  LOG(`附着: ${mainTarget.title} ${mainTarget.url}`);

  const cdp = await new Cdp(mainTarget.webSocketDebuggerUrl).connect();
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");

  // 先读当前状态 (不改动)
  const before = await cdp.eval(`(function(){
    var out = {};
    out.hasGlobal = (typeof __STATSIG__ !== "undefined");
    if (out.hasGlobal) {
      var g = __STATSIG__;
      out.instanceKeys = g.instances ? Object.keys(g.instances) : [];
      out.hasFirst = !!g.firstInstance;
      out.documentLang = document.documentElement.lang;
    }
    out.bodySample = (document.body && document.body.innerText || "").slice(0, 150);
    return JSON.stringify(out);
  })()`);
  LOG(`当前状态: ${(before.result && before.result.value) || JSON.stringify(before.result)}`);

  // Statsig client 实例由 React StatsigProvider 挂载后才注册到 __STATSIG__.instances,
  // 冷启动注入时往往还没注册。轮询等待实例出现 (最多 60s) 再注入。
  const inject = async () => {
    const r = await cdp.eval(injectExpr);
    return JSON.parse((r.result && r.result.value) || JSON.stringify(r.result));
  };
  let res;
  {
    const t0 = Date.now();
    let lastStatus = "";
    for (;;) {
      res = await inject();
      if (res.found > 0) break;
      const remainMs = 60000 - (Date.now() - t0);
      if (remainMs <= 0) {
        LOG(`等待 Statsig 实例 ${((Date.now() - t0) / 1000).toFixed(0)}s 超时, reload 后重注:`);
        await cdp.send("Page.reload", { ignoreCache: false });
        for (let i = 0; i < 30; i++) {
          await new Promise((rr) => setTimeout(rr, 2000));
          res = await inject();
          if (res.found > 0) { LOG(`reload 后第 ${i + 1} 次探测成功。`); break; }
        }
        break;
      }
      const status = res.errors.join(";");
      if (status && status !== lastStatus) {
        lastStatus = status;
        LOG(`  等待 Statsig 实例注册中 ... (${status})`);
      }
      await new Promise((rr) => setTimeout(rr, 2000));
    }
  }
  LOG(`注入结果: found=${res.found}, patched=${res.patched}, persisted=${res.persisted}`);
  LOG(`  before: ${JSON.stringify(res.before)}`);
  LOG(`  after:  ${JSON.stringify(res.after)}`);
  if (res.errors.length) LOG(`  errors: ${res.errors.join("; ")}`);
  if (res.persistKey) LOG(`  持久化缓存键: ${res.persistKey} (冷启动将自动恢复, 免梯子)`);
  if (res.persistKeys && res.persistKeys.length) LOG(`  实际写入键: ${res.persistKeys.join(", ")}`);
  if (res.ui) LOG(`  UI 关键词: zh=[${res.ui.zhUiHits}] en=[${res.ui.enUiHits}] lang=${res.ui.docLang}`);

  if (res.patched > 0) {
    LOG("内存中已覆盖 Statsig layer, 执行 Page.reload 让 React 重新读 gate:");
    await cdp.send("Page.reload", { ignoreCache: false });
    // 轮询验证: 页面 reload 后正文渲染需要时间 (登录态 "Loading profile" 可达 30s+)。
    // 判定标准 (任一满足即算成功):
    //   a) docLang === zh-CN  (FO 已解析出中文 locale, 本地消息包已加载)
    //   b) 中文 UI 关键词命中且无英文关键词
    // 最多等 90s (30 次 x 3s), 避免正文未渲染完就误判为"仍英文"触发兜底。
    let v2 = null;
    let success = false;
    for (let i = 0; i < 30; i++) {
      await new Promise((rr) => setTimeout(rr, 3000));
      const v = await cdp.eval(`(function(){
        var L = ${JSON.stringify(LAYER_ID)};
        var out = {};
        try {
          var g = (typeof __STATSIG__ !== "undefined") ? __STATSIG__ : null;
          var c = g && ((g.instances && g.instances[Object.keys(g.instances)[0]]) || g.firstInstance);
          if (c && c.getLayer) {
            var l = c.getLayer(L);
            out.layer = l ? {
              enable_i18n: l.get ? l.get("enable_i18n", null) : null,
              locale_source: l.get ? l.get("locale_source", null) : null
            } : null;
          }
          var zhUi = ["设置","新对话","定时","插件","项目","最近","书签","模型","语音","文件","关闭","取消","搜索","帮助","语言","无聊天","重新加载","新聊天"];
          var enUi = ["Settings","New chat","Scheduled","Plugins","Projects","Recents","Bookmarks","Model","Voice","Files","Cancel","Search","Help","Language","No chats","Reload"];
          var text = (document.body && document.body.innerText || "");
          out.zhUiHits = zhUi.filter(function(w){ return text.indexOf(w) >= 0; });
          out.enUiHits = enUi.filter(function(w){ return text.indexOf(w) >= 0; });
          out.docLang = document.documentElement.lang;
        } catch(e) { out.err = String(e); }
        return JSON.stringify(out);
      })()`);
      v2 = (v.result && v.result.value) || JSON.stringify(v.result);
      let ok = false;
      try {
        const chk = JSON.parse(v2);
        ok =
          (chk.docLang === TARGET_LOCALE || chk.docLang === TARGET_LOCALE.toLowerCase()) ||
          ((chk.zhUiHits && chk.zhUiHits.length > 0) && (!chk.enUiHits || chk.enUiHits.length === 0));
      } catch {}
      if (ok) { success = true; break; }
    }
    const v2str = v2 || "{}";
    LOG(`reload 后: ${v2str}`);
    if (success) {
      LOG("✔ 中文界面已生效, 缓存已持久化 (冷启动自动恢复, 免梯子)。");
    } else {
      let stillEnglish = false;
      try {
        const chk = JSON.parse(v2str);
        stillEnglish = chk.enUiHits && chk.enUiHits.length > 0 && (!chk.zhUiHits || chk.zhUiHits.length === 0);
      } catch {}
      if (stillEnglish) {
        LOG("Statsig 层已写入但 UI 仍偏英文, 启用本地 localeOverride 兜底 ...");
        const rp = patchLocalLocaleOverride();
        LOG(`  本地兜底: ${JSON.stringify(rp)}`);
        if (rp.patched.length) LOG("兜底已写入本地配置, 需重启 Codex 生效。");
      } else {
        LOG("未检测到英文关键词, 但 90s 内未确认中文 (正文可能尚未渲染完)。");
        LOG("缓存已写入 localStorage, 中文界面已经实现。");
      }
    }
  } else {
    LOG("Statsig 实例始终未注册 (未登录或应用未就绪), 启用本地 localeOverride 兜底:");
    const rp = patchLocalLocaleOverride();
    LOG(`  本地兜底: ${JSON.stringify(rp)}`);
    if (rp.patched.length) LOG("兜底已写入本地配置, 需重启 Codex 生效。");
  }

  cdp.close();
  LOG("完成。");
}
main().catch((e) => { LOG("错误:", e.stack || e.message || String(e)); process.exit(1); });
